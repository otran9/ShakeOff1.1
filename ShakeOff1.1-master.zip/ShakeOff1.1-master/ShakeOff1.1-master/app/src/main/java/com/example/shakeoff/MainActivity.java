package com.example.shakeoff;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;
import androidx.annotation.Nullable;
import java.io.IOException;
import java.util.Calendar;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private int year, month, day, hour, setHour, minute;
    private EditText yearText, monthText, dayText, hrText, minText;
    private Button startButton, setImageButton;
    private Switch AM_PM;
    private String AM_PM_String = " AM";
    private Intent alarmIntent;
    private boolean isPM;
    private Calendar currentTime, alarmTime;
    Handler handler;
    Runnable runnable;

    private int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentTime = Calendar.getInstance();
        alarmTime = Calendar.getInstance();

        year = currentTime.get(Calendar.YEAR);
        month = currentTime.get(Calendar.MONTH) + 1;
        day = currentTime.get(Calendar.DAY_OF_MONTH);
        hour = currentTime.get(Calendar.HOUR_OF_DAY);
        setHour = currentTime.get(Calendar.HOUR_OF_DAY);
        minute = currentTime.get(Calendar.MINUTE);
        /*
        year = 0;
        month = 0;
        day = 0;
        hour = 0;
        setHour = 0;
        minute = 0;
         */
        updateAlarmTime();

        yearText = findViewById(R.id.year);
        monthText = findViewById(R.id.month);
        dayText = findViewById(R.id.day);
        hrText = findViewById(R.id.hour);
        minText = findViewById(R.id.minute);

        yearText.setText(String.valueOf(year));
        monthText.setText(String.valueOf(month));
        dayText.setText(String.valueOf(day));
        hrText.setText(String.valueOf(hour));
        minText.setText(String.valueOf(minute));

        isPM = false;

        startButton = findViewById(R.id.startAlarm);
        AM_PM = findViewById(R.id.AM_PM);
        setImageButton = findViewById(R.id.setImage);

        AM_PM.setText("AM");
        AM_PM.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    isPM = true;
                    AM_PM.setText("PM");
                    AM_PM_String = " PM";
                } else {
                    isPM = false;
                    AM_PM.setText("AM");
                    AM_PM_String = " AM";
                }
            }
        });

        alarmIntent = new Intent(getApplicationContext(), AlarmActivity.class);

        yearText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() == 0) {
                    year = currentTime.get(Calendar.YEAR);
                    return;
                }
                year = Integer.parseInt(charSequence.toString());
            }
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        monthText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() == 0) {
                    month = currentTime.get(Calendar.MONTH);
                    return;
                }
                month = Integer.parseInt(charSequence.toString());
                if (month > 12 || month < 1) {
                    month = currentTime.get(Calendar.MONTH);
                    monthText.setText(String.valueOf(month));
                }
            }
            @Override
            public void afterTextChanged(Editable editable) { }
        });
        dayText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() == 0) {
                    day = currentTime.get(Calendar.DAY_OF_MONTH);
                    return;
                }
                day = Integer.parseInt(charSequence.toString());
                if (day > 31 || day < 1) {
                    day = currentTime.get(Calendar.DAY_OF_MONTH);
                    dayText.setText(String.valueOf(day));
                }
            }
            @Override
            public void afterTextChanged(Editable editable) { }
        });
        hrText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() == 0) {
                    hour = 12;
                    return;
                }
                hour = Integer.parseInt(charSequence.toString());
                if (hour > 12 || hour < 1) {
                    hour = 12;
                    hrText.setText("12");
                }
            }
            @Override
            public void afterTextChanged(Editable editable) { }
        });
        minText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() == 0) {
                    minute = 0;
                    return;
                }
                minute = Integer.parseInt(charSequence.toString());
                if (minute > 59) {
                    minute = 59;
                    minText.setText("59");
                } else if (minute < 0) {
                    minute = 0;
                    minText.setText("00");
                }
            }
            @Override
            public void afterTextChanged(Editable editable) { }
        });

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                currentTime = Calendar.getInstance();
                if (isTime(currentTime, alarmTime)) {
                    handler.removeCallbacks(this);
                    startActivity(alarmIntent);
                } else {
                    handler.postDelayed(this, 1000);
                }
            }
        };
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.startAlarm:
                updateAlarmTime();
                handler.removeCallbacks(runnable);
                handler.postDelayed(runnable, 1000);
                String message = "Current time: "
                        + (currentTime.get(Calendar.MONTH) + 1) + "/"
                        + currentTime.get(Calendar.DAY_OF_MONTH) + "/"
                        + currentTime.get(Calendar.YEAR)
                        + " (" + currentTime.get(Calendar.HOUR_OF_DAY) + ") "
                        + currentTime.get(Calendar.HOUR) + ":"
                        + currentTime.get(Calendar.MINUTE)
                        + "\nAlarm set for "
                        + (alarmTime.get(Calendar.MONTH) + 1) + "/"
                        + alarmTime.get(Calendar.DAY_OF_MONTH) + "/"
                        + alarmTime.get(Calendar.YEAR)
                        + " (" + alarmTime.get(Calendar.HOUR_OF_DAY) + ") "
                        + alarmTime.get(Calendar.HOUR) + ":"
                        + alarmTime.get(Calendar.MINUTE) + AM_PM_String;
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                break;
            case R.id.setImage:
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
                break;
        }
    }

    boolean isTime(Calendar currentTime, Calendar alarmTime) {
        boolean matchTime = false;

        if (currentTime.get(Calendar.YEAR) == alarmTime.get(Calendar.YEAR)) {
            if (currentTime.get(Calendar.MONTH) == alarmTime.get(Calendar.MONTH)) {
                if (currentTime.get(Calendar.DAY_OF_MONTH) == alarmTime.get(Calendar.DAY_OF_MONTH)) {
                    if (currentTime.get(Calendar.HOUR_OF_DAY) == alarmTime.get(Calendar.HOUR_OF_DAY)) {
                        if (currentTime.get(Calendar.MINUTE) == alarmTime.get(Calendar.MINUTE)) {
                            matchTime = true;
                        }
                    }
                }
            }
        }
        return matchTime;
    }

    void updateAlarmTime() {
        currentTime = Calendar.getInstance();
        if (isPM) { // PM
            if (hour == 12) {
                setHour = hour; // Set 12 to 12
            } else {
                setHour = hour + 12;
            }
        } else if (!isPM) { // AM
            if (hour == 12) {
                setHour = 0; // Set 12 to 0
            } else {
                setHour = hour;
            }
        }
        alarmTime.set(Calendar.YEAR, year);
        alarmTime.set(Calendar.MONTH, month - 1);
        alarmTime.set(Calendar.DAY_OF_MONTH, day);
        alarmTime.set(Calendar.HOUR, hour);
        alarmTime.set(Calendar.HOUR_OF_DAY, setHour);
        alarmTime.set(Calendar.MINUTE, minute);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                ImageView imageView = findViewById(R.id.imageView2);
                imageView.setImageBitmap(bitmap);
                alarmIntent.setData(uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
